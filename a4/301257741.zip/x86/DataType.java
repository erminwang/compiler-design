package x86;


public enum DataType {
		INT, BOOLEAN, LABEL, VOID, STR, INVALID
}	